package com.hariz.movienightplanner.listeners;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.hariz.movienightplanner.models.InMemoryDataManager;

public class EventDetailContactListLongClickListener implements AdapterView.OnItemLongClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private int eventPosition;
    private ArrayAdapter<String> adapter;

    public EventDetailContactListLongClickListener(int eventPosition, ArrayAdapter<String> adapter) {
        this.eventPosition = eventPosition;
        this.adapter = adapter;
    }


            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {


                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage("Are you sure to delete " + dataManager.eventLists.get(eventPosition).getAttendees().get(eventPosition));
                builder.setCancelable(true);

                builder.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                dataManager.eventLists.get(eventPosition).getAttendees().remove(eventPosition);
                                adapter.notifyDataSetChanged();
                            }
                        });
                builder.setNegativeButton(
                        "Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });

                AlertDialog alert = builder.create();
                alert.show();
                return true;
            }

        }

