package com.hariz.movienightplanner.database;


import java.util.ArrayList;
import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.models.Movie;


public class Database extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "eventsdb.db";

    public static final String EVENTS_TABLE_NAME = "events";
    public static final String EVENTS_COLUMN_ID = "eventId";
    public static final String EVENTS_COLUMN_TITLE = "eventTitle";
    public static final String EVENTS_COLUMN_STARTDATE = "eventStartDate";
    public static final String EVENTS_COLUMN_ENDDATE = "eventEndDate";
    public static final String EVENTS_COLUMN_VENUE= "eventVenue";
    public static final String EVENTS_COLUMN_LOCATION = "eventLocation";
    public static final String EVENTS_COLUMN_MOVIEID = "movieId";

    public static final String MOVIES_TABLE_NAME = "movies";
    public static final String MOVIES_COLUMN_ID = "movieId";
    public static final String MOVIES_COLUMN_TITLE = "movieTitle";
    public static final String MOVIES_COLUMN_YEAR = "movieYear";
    public static final String MOVIES_COLUMN_POSTERIMAGENAME = "moviePoster";

    public static final String ATTENDANCE_TABLE_NAME = "attendance";
    public static final String ATTENDANCE_COLUMN_EVENTID = "eventId";
    public static final String ATTENDANCE_COLUMN_ATTENDEESNAME = "attendeesName";


    private HashMap hp;

    public Database(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // generate tables with SQL queries
        db.execSQL(
                "create table " + MOVIES_TABLE_NAME +
                        "("+ MOVIES_COLUMN_ID + " integer primary key, " + MOVIES_COLUMN_TITLE +" text," + MOVIES_COLUMN_YEAR + " text, " + MOVIES_COLUMN_POSTERIMAGENAME + " text, UNIQUE (" + MOVIES_COLUMN_ID +"," + MOVIES_COLUMN_TITLE + ") ON CONFLICT REPLACE)"
        );
        db.execSQL(
                "create table " + EVENTS_TABLE_NAME +
                        "(" + EVENTS_COLUMN_ID + " integer primary key, " + EVENTS_COLUMN_TITLE + " text," + EVENTS_COLUMN_STARTDATE + " text, " + EVENTS_COLUMN_ENDDATE + " text, " + EVENTS_COLUMN_VENUE + " text," + EVENTS_COLUMN_LOCATION + " text," + EVENTS_COLUMN_MOVIEID + " integer, foreign key(" + EVENTS_COLUMN_MOVIEID +") REFERENCES " + MOVIES_TABLE_NAME + "("+ MOVIES_COLUMN_ID + "),UNIQUE (" + EVENTS_COLUMN_ID +"," + EVENTS_COLUMN_TITLE + ") ON CONFLICT REPLACE)"
        );
        db.execSQL(
                "create table " + ATTENDANCE_TABLE_NAME +
                        "(" + ATTENDANCE_COLUMN_EVENTID + " integer, " + ATTENDANCE_COLUMN_ATTENDEESNAME + " text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop tables in reasonable order
        db.execSQL("DROP TABLE IF EXISTS ATTENDEES_TABLE_NAME");
        db.execSQL("DROP TABLE IF EXISTS MOVIES_TABLE_NAME");
        db.execSQL("DROP TABLE IF EXISTS EVENTS_TABLE_NAME");
        db.execSQL("DROP TABLE IF EXISTS ATTENDANCE_TABLE_NAME");
        onCreate(db);
    }

    //add an Event
    public void insertEvent (Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENTS_COLUMN_TITLE, event.getTitle());
        contentValues.put(EVENTS_COLUMN_STARTDATE, event.getStartDate());
        contentValues.put(EVENTS_COLUMN_ENDDATE, event.getEndDate());
        contentValues.put(EVENTS_COLUMN_VENUE, event.getVenue());
        contentValues.put(EVENTS_COLUMN_LOCATION, event.getLocation());
        db.insert(EVENTS_TABLE_NAME, null, contentValues);

    }

    //add a Movie
    public void insertMovie (Movie movie) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(MOVIES_COLUMN_TITLE, movie.getTitle());
        contentValues.put(MOVIES_COLUMN_YEAR, movie.getYear());
        contentValues.put(MOVIES_COLUMN_POSTERIMAGENAME, movie.getPoster());
        db.insert(MOVIES_TABLE_NAME, null, contentValues);

    }

    //Add an Attendee with an Event
    public boolean insertAttendance (String eventId, String attendeeName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ATTENDANCE_COLUMN_EVENTID, eventId);
        contentValues.put(ATTENDANCE_COLUMN_ATTENDEESNAME, attendeeName);
        db.insert(ATTENDANCE_TABLE_NAME, null, contentValues);
        return true;
    }

    //Update event
    public boolean editEvent (Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENTS_COLUMN_TITLE, event.getTitle());
        contentValues.put(EVENTS_COLUMN_STARTDATE, event.getStartDate());
        contentValues.put(EVENTS_COLUMN_ENDDATE, event.getEndDate());
        contentValues.put(EVENTS_COLUMN_VENUE, event.getVenue());
        contentValues.put(EVENTS_COLUMN_LOCATION, event.getLocation());
        db.update(EVENTS_TABLE_NAME, contentValues,  EVENTS_COLUMN_ID + " = ? ", new String[] { event.getId() } );
        return true;
    }

    //Link move with event
    public boolean addMovieToEvent (String eventId, String movieId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENTS_COLUMN_MOVIEID, movieId);
        db.update(EVENTS_TABLE_NAME, contentValues,  EVENTS_COLUMN_ID + " = ? ", new String[] { eventId } );
        return true;
    }


    //remove Attendance
    public void deleteAttendeeFromEvent (String eventId, String attendeeName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + ATTENDANCE_TABLE_NAME + " where " + ATTENDANCE_COLUMN_EVENTID + "=" + eventId + " and " + ATTENDANCE_COLUMN_ATTENDEESNAME + "=" + attendeeName);
    }


    //get all attendees for an Event
    public ArrayList<String> getAttendeesOfEvent(String eventId) {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ ATTENDANCE_TABLE_NAME + " where " + ATTENDANCE_COLUMN_EVENTID + " = " + eventId, null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            array_list.add(res.getString(res.getColumnIndex(ATTENDANCE_COLUMN_ATTENDEESNAME)));
            res.moveToNext();
        }
        return array_list;
    }

    //get all events
    public ArrayList<Event> getAllEvents() {
        ArrayList<Event> eventsList = new ArrayList<Event>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ EVENTS_TABLE_NAME, null );
        res.moveToFirst();

        while(res.isAfterLast() == false){


            Event event = new Event(res.getString(res.getColumnIndex(EVENTS_COLUMN_ID)),res.getString(res.getColumnIndex(EVENTS_COLUMN_TITLE)),res.getString(res.getColumnIndex(EVENTS_COLUMN_STARTDATE)),res.getString(res.getColumnIndex(EVENTS_COLUMN_ENDDATE)),res.getString(res.getColumnIndex(EVENTS_COLUMN_VENUE)),res.getString(res.getColumnIndex(EVENTS_COLUMN_LOCATION)));

            // check if movie is attached
            String movieId = res.getString(res.getColumnIndex(EVENTS_COLUMN_MOVIEID));
          if(movieId != null)
            event.setMovie(getMovie(movieId));
          event.setAttendees(getAttendeesOfEvent(event.getId()));
          eventsList.add(event);

            res.moveToNext();
        }


        return eventsList;
    }

    //get all movies
    public ArrayList<Movie> getAllMovies() {
        ArrayList<Movie> array_list = new ArrayList<Movie>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ MOVIES_TABLE_NAME, null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            array_list.add(new Movie(res.getString(res.getColumnIndex(MOVIES_COLUMN_ID)),res.getString(res.getColumnIndex(MOVIES_COLUMN_TITLE)),res.getString(res.getColumnIndex(MOVIES_COLUMN_YEAR)),res.getString(res.getColumnIndex(MOVIES_COLUMN_POSTERIMAGENAME))));
            res.moveToNext();
        }
        return array_list;
    }

    public Movie getMovie(String movieId) {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ MOVIES_TABLE_NAME +"where "+ MOVIES_COLUMN_ID +"=" + movieId , null );
        res.moveToFirst();

        if(res.moveToNext()){
           return  new Movie(res.getString(res.getColumnIndex(MOVIES_COLUMN_ID)),res.getString(res.getColumnIndex(MOVIES_COLUMN_TITLE)),res.getString(res.getColumnIndex(MOVIES_COLUMN_YEAR)),res.getString(res.getColumnIndex(MOVIES_COLUMN_POSTERIMAGENAME)));

        }
        return null;
    }


    public void removeAllEvents() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ EVENTS_TABLE_NAME);

    }

    public void removeAllMovies() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ MOVIES_TABLE_NAME);
    }

    public void removeAllAttendees() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ ATTENDANCE_TABLE_NAME);
    }
}