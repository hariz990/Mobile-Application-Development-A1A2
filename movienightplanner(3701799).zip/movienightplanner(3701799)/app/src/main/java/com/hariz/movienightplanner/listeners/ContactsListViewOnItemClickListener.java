package com.hariz.movienightplanner.listeners;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

import com.hariz.movienightplanner.models.InMemoryDataManager;

import java.util.List;

public class ContactsListViewOnItemClickListener implements AdapterView.OnItemClickListener {
    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private Intent intent;
    private List<String> contactsList;

    public ContactsListViewOnItemClickListener(Intent intent, List<String> contactsList) {
        this.intent = intent;
        this.contactsList = contactsList;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {

        //get the right event by event position parameter passed from last page
        int eventPosition = intent.getIntExtra("position", 1);

        //check if this person have already been invited
        if (dataManager.eventLists.get(eventPosition).getAttendees().contains(contactsList.get(position))) {
            //show alert to tell the contact have been added
            AlertDialog.Builder builder= new AlertDialog.Builder(view.getContext());
            builder.setMessage("This person already exits");
            builder.setCancelable(true);

            builder.setPositiveButton(
                    "ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();
        } else {
            List<String> newContacts = dataManager.eventLists.get(eventPosition).getAttendees();
            newContacts.add(contactsList.get(position));

            dataManager.eventLists.get(eventPosition).setAttendees(newContacts);

            //show alert to tell the contact have been added
            AlertDialog.Builder builder= new AlertDialog.Builder(view.getContext());
            builder.setMessage(contactsList.get(position) + " has been added to " + dataManager.eventLists.get(eventPosition).getTitle());
            builder.setCancelable(true);

            builder.setPositiveButton(
                    "ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
//                            onBackPressed();
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();
        }

    }
}
