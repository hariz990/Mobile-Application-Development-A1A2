package com.hariz.movienightplanner.views.movie;

import android.app.AlertDialog;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.listeners.AddEditMovieOnclickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Movie;

import java.io.IOException;
import java.io.InputStream;

public class AddEditMovieActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private EditText titleText;
    private EditText yearText;
    private TextView posterText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_movie);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int moviePosition = getIntent().getIntExtra("position", -1);
        if(moviePosition > -1){
            setTitle(R.string.edit_movie);
        } else {
            setTitle(R.string.add_movie);
        }


        View addNewButton = findViewById(R.id.fab);
        titleText = (EditText) findViewById(R.id.edtTitle);
        yearText = (EditText) findViewById(R.id.edtYear);
        posterText =  findViewById(R.id.edtPoster);


        if (moviePosition != -1) {
            Movie event = dataManager.moviesList.get(moviePosition);
            titleText.setText(event.getTitle());
            yearText.setText(event.getYear());
            posterText.setText(event.getPoster());

        }
        posterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectPoster();
            }
        });

        addNewButton.setOnClickListener(new AddEditMovieOnclickListener(this, titleText,yearText, posterText, moviePosition));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }

    String[] images = new String[0];
    private void selectPoster(){


        AssetManager assetManager = getAssets();
        // to get all item in dogs folder.
        try {
            images = assetManager.list("posters");

            final Drawable[] drawables = new Drawable[images.length];
        for(int i=0;i<images.length;i++)
        {
            InputStream inputStream = getAssets().open("posters/" + images[i]);
            Drawable d = Drawable.createFromStream(inputStream, null);
            drawables[i] = d;

            inputStream.close();
        }


        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.poster_picker);
        ListView lv = new ListView(this);
        lv.setAdapter(new ArrayAdapter<String>(this, R.layout.item_poster_picker) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                Drawable drawable = drawables[position];
                String name =  images[position];
                View v = getLayoutInflater().inflate(R.layout.item_poster_picker, null) ;
                ImageView imageView = v.findViewById(R.id.imgPoster);
                TextView txtView = v.findViewById(R.id.txtImgName);
                imageView.setImageDrawable(drawable);
                txtView.setText(name);
                return v;
            }

            @Override
            public int getCount() {
                return images.length;
            }
        });

        builder.setView(lv);
       final AlertDialog dialog = builder.create();
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long arg3) {
                    posterText.setText(images[pos]);//.replace(".jpg", "").replace(".png", ""));
                    dialog.dismiss();
                }

            });
            dialog.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
