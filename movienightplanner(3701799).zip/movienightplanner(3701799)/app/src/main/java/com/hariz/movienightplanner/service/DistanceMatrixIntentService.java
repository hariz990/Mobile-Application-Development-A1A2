package com.hariz.movienightplanner.service;

import android.Manifest;
import android.app.IntentService;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.net.ConnectivityManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.models.InMemoryDataManager;

import com.hariz.movienightplanner.views.event.EventDetailActivity;
import com.hariz.movienightplanner.location.LocationTracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;


public class DistanceMatrixIntentService extends IntentService {
    private static final int VIEW_EVENT_REQUEST = 101;
    private InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();

    public static final long DEFAULT_INTERVAL_MS = 5 * 60 * 1000; // which is 5 min
    public static final long DEFAULT_THRESHOLD_MS = 15 * 60 * 1000; //which is  15 min

    private static final String LOG_TAG = DistanceMatrixIntentService.class
            .getSimpleName();
    private static final String DISTANCE_MATRIX_URL
            = "https://maps.googleapis.com/maps/api/distancematrix/json"
            + "?origins=%s&destinations=%s";


    public DistanceMatrixIntentService() {
        super("DistanceMatrixIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.i(LOG_TAG, "Running distance matrix service");

        // Check network availability
        if (!isOnline()) {
            Log.i(LOG_TAG, "No network connectivity");
            Toast.makeText(this, "No network connectivity", Toast.LENGTH_SHORT).show();
            return;
        }


        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show();

            return;
        }
        fusedLocationClient
                .getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(final Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            try {

                                new AsyncTask<Object,  Integer,Map<Event, Long>>(){

                                    @Override
                                    protected  Map<Event, Long> doInBackground(Object[] objects) {
                                        try {
                                            return getTravelTimeToEvents(
                                                   location);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                        return new HashMap<>();
                                    }

                                    @Override
                                    protected void onPostExecute(Map<Event, Long> travelTimeToEvents) {

                                        SharedPreferences prefs = PreferenceManager
                                                .getDefaultSharedPreferences(getApplicationContext());
                                        long threshold = prefs.getLong("notif_threshold",
                                                DistanceMatrixIntentService.DEFAULT_THRESHOLD_MS);
                                        for (Map.Entry<Event, Long> pair
                                                : travelTimeToEvents.entrySet()) {
                                            Event event = pair.getKey();
                                            long travelTime = pair.getValue();

                                            long eventStartMs = dataManager.convertToDate(event.getStartDate()).getTime();
                                            long travelTimeMs = travelTime * 1000;
                                            long currentTime = System.currentTimeMillis();

                                            // Skip events that don't meet the criteria
                                            if (((eventStartMs - (travelTimeMs + threshold)) > currentTime)
                                                    || (eventStartMs < currentTime)) {
                                                continue;
                                            }

                                            // Create intent for clicking on notification
                                            Intent viewEventIntent = new Intent(DistanceMatrixIntentService.this,
                                                    EventDetailActivity.class);
                                            viewEventIntent.putExtra("eventId", event.getId());
                                            PendingIntent viewEventPendingIntent = PendingIntent.
                                                    getActivity(DistanceMatrixIntentService.this, VIEW_EVENT_REQUEST,
                                                            viewEventIntent,
                                                            PendingIntent.FLAG_UPDATE_CURRENT);

                                            // Create the notification itself
                                            Notification notification
                                                    = new NotificationCompat.Builder(DistanceMatrixIntentService.this, "EVENTS")
                                                    .setSmallIcon(R.mipmap.ic_launcher)
                                                    .setContentTitle(getResources().getString(
                                                            R.string.notification_title, event.getTitle()))
                                                    .setContentText(getResources().getString(
                                                            R.string.notification_text,
                                                            millisToDisplay(eventStartMs - currentTime),
                                                            secondsToDisplay(travelTime)))
                                                    .setContentIntent(viewEventPendingIntent)
                                                    .setAutoCancel(true)
                                                    .build();

                                            // Display the notification
                                            NotificationManagerCompat notifyMgr
                                                    = NotificationManagerCompat.from(DistanceMatrixIntentService.this);
                                            notifyMgr.notify(generateNotificationId(), notification);
                                        }
                                    }
                                }.execute();


                            } catch (Exception e) {
                                Log.e(LOG_TAG, e.getMessage(), e);
                                Toast.makeText(DistanceMatrixIntentService.this, "Some error occurred while getting distances", Toast.LENGTH_SHORT).show();

                            }

                        }else{
                            Toast.makeText(DistanceMatrixIntentService.this, "Location does not received", Toast.LENGTH_SHORT).show();

                        }
                    }
                });



    }


    private boolean isOnline()
    {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager
                .getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    private Map<Event, Long> getTravelTimeToEvents(Location currentLocation)
            throws IOException, JSONException
    {
        List<Event> events = dataManager.eventLists;

        if (events.isEmpty())
        {
            return new HashMap<>();
        }

        String dests = "";
        for (int i = 0; i < events.size(); i++)
        {
            dests += events.get(i).getLocation();
            if (i != events.size() - 1)
            {
                dests += "%7C";
            }
        }
        // Construct 'origins' parameter for URL
        String origin = currentLocation.getLatitude() + ","
                + currentLocation.getLongitude();
        // Construct URL for distance matrix API call
        String urlStr = String.format(DISTANCE_MATRIX_URL, origin, dests);

        // Perform distance matrix API call
        URL url = new URL(urlStr);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.connect();

        int responseCode = connection.getResponseCode();
        if (responseCode != 200)
        {

            return null;
        }

        Map<Event, Long> travelTimeToEvents = new HashMap<>();

        String jsonStr = new Scanner(connection.getInputStream())
                .useDelimiter("\\A").next();
        JSONObject jsonResult =  new JSONObject(jsonStr);
        JSONArray distMatrixElements = jsonResult.getJSONArray("rows")
                .getJSONObject(0).getJSONArray("elements");
        for (int i = 0; i < distMatrixElements.length(); i++)
        {
            travelTimeToEvents.put(events.get(i),
                    distMatrixElements.getJSONObject(i)
                            .getJSONObject("duration").getLong("value"));
        }

        return travelTimeToEvents;
    }

    private int generateNotificationId()
    {
        long now = System.currentTimeMillis();
        String nowStr = String.valueOf(now);

        return Integer.valueOf(nowStr.substring(nowStr.length() - 6));
    }

    private static String millisToDisplay(long millis)
    {
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60;

        return String.format(Locale.getDefault(), "%dh, %dm, %ds",
                hours, minutes, seconds);
    }

    private static String secondsToDisplay(long secs)
    {
        return millisToDisplay(secs * 1000);
    }
}
