package com.hariz.movienightplanner.listeners;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.views.event.AddEditEventActivity;

public class AddNewEventOnClickListener implements View.OnClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private AddEditEventActivity activity;
    final EditText titleText;
    final EditText startDateText;
    final EditText endDateText;
    final EditText venueText;
    final EditText locationText;

    public AddNewEventOnClickListener(AddEditEventActivity activity, EditText tittleText, EditText startDateText, EditText endDateText, EditText venueText, EditText locationText) {
        this.activity = activity;
        this.titleText = tittleText;
        this.startDateText = startDateText;
        this.endDateText = endDateText;
        this.venueText = venueText;
        this.locationText = locationText;
    }

    @Override
    public void onClick(View v) {

        //check if input was empty
        if (titleText.getText().toString().isEmpty()) {
            dataManager.showAlert("Title can not be empty", v.getContext());
        } else if (startDateText.getText().toString().isEmpty()) {
            dataManager.showAlert("Start date can not be empty", v.getContext());
        } else if (endDateText.getText().toString().isEmpty()) {
            dataManager.showAlert("End date can not be empty", v.getContext());
        } else if (venueText.getText().toString().isEmpty()) {
            dataManager.showAlert("Venue can not be empty", v.getContext());
        } else if (locationText.getText().toString().isEmpty()) {
            dataManager.showAlert("Location can not be empty !", v.getContext());
        }  else {
            Event newEvents = new Event("" + System.currentTimeMillis(), titleText.getText().toString(), startDateText.getText().toString(), endDateText.getText().toString(), venueText.getText().toString(), locationText.getText().toString());
            dataManager.eventLists.add(newEvents);

            Toast.makeText(activity, "Event created successfully", Toast.LENGTH_SHORT).show();
            activity.finish();
        }

    }
}
