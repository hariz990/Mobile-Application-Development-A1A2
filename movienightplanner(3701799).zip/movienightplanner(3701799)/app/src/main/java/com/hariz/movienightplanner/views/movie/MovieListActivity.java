package com.hariz.movienightplanner.views.movie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.adapter.MoviesListAdapter;
import com.hariz.movienightplanner.listeners.MovieListViewOnLongClickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;

public class MovieListActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private ListView listView;
    private MoviesListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.movies_list);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listAdapter = new MoviesListAdapter(this, dataManager.moviesList);
        listView = (ListView) findViewById(R.id.listView);
        listAdapter.notifyDataSetChanged();
        listView.setAdapter(listAdapter);

        listView.setOnItemLongClickListener(new MovieListViewOnLongClickListener(this,listAdapter));

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;


        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(listAdapter != null) listAdapter.notifyDataSetChanged();
    }

    public void addMovie(View view) {
        startActivity(new Intent(this, AddEditMovieActivity.class));

    }
}
