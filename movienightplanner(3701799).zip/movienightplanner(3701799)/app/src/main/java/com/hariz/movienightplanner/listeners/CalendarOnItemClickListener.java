package com.hariz.movienightplanner.listeners;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Day;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.views.event.EventDetailActivity;

import java.text.SimpleDateFormat;
import java.util.List;

public class CalendarOnItemClickListener implements AdapterView.OnItemClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private List<Day> beans;

    public CalendarOnItemClickListener(List<Day> beans) {
        this.beans = beans;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        if (beans.get(position).getHasEvent()) {
            int index = -1;
            for (Event event : dataManager.eventLists) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                if (sdf.format(dataManager.convertToDate(event.getStartDate())).equals(sdf.format(beans.get(position).getCalendar().getTime()))) {
                    index = dataManager.eventLists.indexOf(event);
                }
            }

            if (index >= 0) {
                Intent intent = new Intent(view.getContext(), EventDetailActivity.class);

                intent.putExtra("position", index);
                view.getContext().startActivity(intent);
            }
        }

    }
}
