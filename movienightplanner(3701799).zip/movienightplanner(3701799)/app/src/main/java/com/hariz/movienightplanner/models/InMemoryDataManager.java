package com.hariz.movienightplanner.models;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;

import com.hariz.movienightplanner.database.Database;
import com.hariz.movienightplanner.models.helper.Constants;
import com.hariz.movienightplanner.views.MainActivity;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class InMemoryDataManager {

    // set up singleton
    private static InMemoryDataManager sharedInstance;

    public List<Movie> moviesList;
    public List<Event> eventLists;

    private boolean dataRead = false;

    public static InMemoryDataManager getSharedInstance() {
        if (sharedInstance == null) {
            sharedInstance = new InMemoryDataManager();
        }
        return sharedInstance;
    }


    public void loadData(Context context) {

        Database database = new Database(context);
        this.moviesList = database.getAllMovies();
        this.eventLists = database.getAllEvents();
        if(this.moviesList.isEmpty()) {
            this.moviesList = initMovieList(context);
        }
        if(this.eventLists.isEmpty()) {
            this.eventLists = initEventsList(context);
        }
        ascendEvents();
        dataRead = true;
    }

    public boolean getDataRead() {
        return dataRead;
    }

    public List<Movie> initMovieList(Context context) {
        List<Movie> list = new ArrayList<Movie>();
        for (String line : readTextFile("movies.txt", context)) {
            String[] splitedLine = line.split("\",\"");
            //add lengeth check
            if (splitedLine.length == 4) {
                list.add(new Movie(splitedLine[0].replace("\"", ""), splitedLine[1].replace("\"", ""), splitedLine[2].replace("\"", ""), splitedLine[3].replace("\"", "")));
            } else {
                showAlert("read txt error occurred", context);
            }
        }
        return list;
    }

    public List<Event> initEventsList(Context context) {
        List<Event> list = new ArrayList<Event>();
        for (String line : readTextFile("events.txt", context)) {
            String[] splitedLine = line.split("\",\"");
            if (splitedLine.length == 6) {
                Event newEvent = new Event(splitedLine[0].replace("\"", ""),
                        splitedLine[1].replace("\"", ""),
                        splitedLine[2].replace("\"", ""),
                        splitedLine[3].replace("\"", ""),
                        splitedLine[4].replace("\"", ""),
                        splitedLine[5].replace("\"", ""));
                list.add(newEvent);
            } else {
                showAlert("read txt error occurred", context);
            }

        }
        return list;
    }

    //will get the function parameter context from main activity
    public List<String> readTextFile(String fileName, Context context) {
        String line = null;
        List<String> lines = new ArrayList<String>();
        try {
            InputStream fileInputStream = context.getAssets().open(fileName);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();

            while ((line = bufferedReader.readLine()) != null) {
                lines.add(line + System.getProperty("line.separator"));
            }
            fileInputStream.close();
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            String TAG = MainActivity.class.getName();
            Log.d(TAG, ex.getMessage());
        } catch (IOException ex) {
            String TAG = MainActivity.class.getName();
            Log.d(TAG, ex.getMessage());
        }
        return lines;
    }

    public Date convertToDate(String inputDate) {
        Date date = new Date();
        SimpleDateFormat formater = new SimpleDateFormat(Constants.DATETIME_FORMAT);
        try {
            date = formater.parse(inputDate);
        } catch (ParseException ex) {
            Log.v("Exception", ex.getLocalizedMessage());
        }
        return date;
    }

    public void ascendEvents() {
        Collections.sort(eventLists, new Comparator<Event>() {
            public int compare(Event o1, Event o2) {
                return convertToDate(o1.getStartDate()).compareTo(convertToDate(o2.getStartDate()));
            }
        });
    }


    public void descendEvents() {
        Collections.sort(eventLists, new Comparator<Event>() {
            public int compare(Event o1, Event o2) {
                return convertToDate(o2.getStartDate()).compareTo(convertToDate(o1.getStartDate()));
            }
        });
    }


    public boolean isValidDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATETIME_FORMAT);
        boolean flag = true;

        try {
            dateFormat.parse(date);
        } catch (ParseException e) {
            flag = false;
        }
        return flag;
    }


    public void showAlert(String message, Context context) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    public void saveData(Context context) {
        Database database = new Database(context);
        database.removeAllEvents();
        database.removeAllMovies();
        database.removeAllAttendees();

        for (Movie movie : moviesList){
            database.insertMovie(movie);
        }

        for (Event event : eventLists){
            database.insertEvent(event);
            if(event.getMovie() != null){
                database.addMovieToEvent(event.getId(), event.getMovie().getId());
            }
            for (String attendee: event.getAttendees()){
                database.insertAttendance(event.getId(), attendee);
            }
        }
    }

    public int findEventIndexById(String eventId) {
        for (int i = 0; i < eventLists.size(); i++) {
            if(eventLists.get(i).getId().equals(eventId)){
                return i;
            }
        }
        return 0;
    }
}
