package com.hariz.movienightplanner.views.movie;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ListView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.adapter.MoviesListAdapter;
import com.hariz.movienightplanner.listeners.MovieListViewOnItemClickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;

public class MovieSelectorActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private ListView listView;
    private MoviesListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.movies_list);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listAdapter = new MoviesListAdapter(this, dataManager.moviesList);
        listView = (ListView) findViewById(R.id.listView);
        listAdapter.notifyDataSetChanged();
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new MovieListViewOnItemClickListener(this,getIntent()));

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }


}
