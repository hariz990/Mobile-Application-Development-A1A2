package com.hariz.movienightplanner.views.contact;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Event;

import java.util.ArrayList;
import java.util.List;

public class ContactsActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private ListView listView;
    private List<String> contactsList;

    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 3234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        this.listView = findViewById(R.id.lstContacts);

        showContacts();

        listView.setOnItemClickListener(new ContactsListViewOnItemClickListener());
    }


    private void showContacts() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_READ_CONTACTS);
        } else {
            contactsList = getContactNames();
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.item_contact,R.id.txtTitle, contactsList);
            listView.setAdapter(adapter);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            return;
        }
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showContacts();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    private List<String> getContactNames() {
        Event event = dataManager.eventLists.get(getIntent().getIntExtra("index",0));

        List<String> contacts = new ArrayList<>();
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
               if(!event.getAttendees().contains(name))
                contacts.add(name);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return contacts;
    }

    class ContactsListViewOnItemClickListener implements AdapterView.OnItemClickListener {


        @Override
        public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {

            int eventPosition = getIntent().getIntExtra("position", 1);
                List<String> newContacts = dataManager.eventLists.get(eventPosition).getAttendees();
                newContacts.add(contactsList.get(position));
                dataManager.eventLists.get(eventPosition).setAttendees(newContacts);
                Toast.makeText(ContactsActivity.this, contactsList.get(position) + " has been added", Toast.LENGTH_SHORT).show();
                finish();
        }
    }
}
