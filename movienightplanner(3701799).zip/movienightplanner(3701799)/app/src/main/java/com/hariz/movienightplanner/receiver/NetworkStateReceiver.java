package com.hariz.movienightplanner.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

import com.hariz.movienightplanner.service.ServiceManager;

public class NetworkStateReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(final Context context, final Intent intent) {

            if(checkInternet(context))
            {
                Toast.makeText(context, "Network connected, starting distance matrix service",Toast.LENGTH_LONG).show();
                ServiceManager.getSingletonInstance(context).startDistanceMatrixBackgroundService(false);
            }

        }

        boolean checkInternet(Context context) {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        }

    }