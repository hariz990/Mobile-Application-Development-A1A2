package com.hariz.movienightplanner.listeners;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.views.event.AddEditEventActivity;
import com.hariz.movienightplanner.views.MainActivity;

public class EditEventOnclickListener implements View.OnClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private AddEditEventActivity activity;
    final EditText titleText;
    final EditText startDateText;
    final EditText endDateText;
    final EditText venueText;
    final EditText locationText;
    private int eventPosition;

    public EditEventOnclickListener(AddEditEventActivity activity, EditText tittleText, EditText startDateText, EditText endDateText, EditText venueText, EditText locationText, int eventPosition) {
        this.activity = activity;
        this.titleText = tittleText;
        this.startDateText = startDateText;
        this.endDateText = endDateText;
        this.venueText = venueText;
        this.locationText = locationText;
        this.eventPosition = eventPosition;
    }

    @Override
    public void onClick(final View v) {

        //check if input was empty
        if (titleText.getText().toString().isEmpty()) {
            dataManager.showAlert("Title can not be empty", v.getContext());
        } else if (startDateText.getText().toString().isEmpty()) {
            dataManager.showAlert("Start date can not be empty", v.getContext());
        } else if (endDateText.getText().toString().isEmpty()) {
            dataManager.showAlert("End date can not be empty", v.getContext());
        } else if (venueText.getText().toString().isEmpty()) {
            dataManager.showAlert("Venue can not be empty", v.getContext());
        } else if (locationText.getText().toString().isEmpty()) {
            dataManager.showAlert("Location can not be empty", v.getContext());
        } else {

            dataManager.eventLists.get(eventPosition).setTitle(titleText.getText().toString());
            dataManager.eventLists.get(eventPosition).setStartDate(startDateText.getText().toString());
            dataManager.eventLists.get(eventPosition).setEndDate(endDateText.getText().toString());
            dataManager.eventLists.get(eventPosition).setVenue(venueText.getText().toString());
            dataManager.eventLists.get(eventPosition).setLocation(locationText.getText().toString());


            Toast.makeText(activity, "Event updated successfully", Toast.LENGTH_SHORT).show();
            activity.finish();
        }

    }
}
