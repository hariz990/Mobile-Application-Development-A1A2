package com.hariz.movienightplanner.views.settings;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.service.DistanceMatrixIntentService;
import com.hariz.movienightplanner.service.ServiceManager;


public class SettingsActivity extends AppCompatActivity
{
    private ServiceManager androidModel;
    private SharedPreferences prefs;
    private EditText notifThresholdField;
    private EditText distanceCheckFreqField;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.settings);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        androidModel = ServiceManager.getSingletonInstance(this);
        prefs =  PreferenceManager.getDefaultSharedPreferences(
                getApplicationContext());


        notifThresholdField = (EditText) findViewById(R.id.edtNotifiThresholdFreq);
        notifThresholdField.setText(
                String.valueOf(prefs.getLong("notif_threshold",
                        DistanceMatrixIntentService.DEFAULT_THRESHOLD_MS)
                        / 1000 / 60));

        distanceCheckFreqField = (EditText) findViewById(R.id.edtDistCheckFreq);
        distanceCheckFreqField.setText(
                String.valueOf(prefs.getLong("distance_check_freq_interval",
                        DistanceMatrixIntentService.DEFAULT_INTERVAL_MS)
                        / 1000 / 60));
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void saveSettings(View view) {
        SharedPreferences prefs = PreferenceManager
                .getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor prefsEditor = prefs.edit();
        prefsEditor.putLong("notif_threshold",
                Long.valueOf(notifThresholdField.getText().toString())
                        * 60 * 1000);
        prefsEditor.putLong("distance_check_freq_interval",
                Long.valueOf(distanceCheckFreqField.getText().toString())
                        * 60 * 1000);
        prefsEditor.apply();

        // Restart background service with new values
        androidModel.startDistanceMatrixBackgroundService(true);
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }
}
