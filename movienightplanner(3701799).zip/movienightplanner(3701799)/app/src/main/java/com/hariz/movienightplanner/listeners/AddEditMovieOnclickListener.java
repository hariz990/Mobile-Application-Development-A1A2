package com.hariz.movienightplanner.listeners;

import android.app.Activity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Movie;

public class AddEditMovieOnclickListener implements View.OnClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private Activity activity;
    final EditText titleText;
    final EditText yearText;
    final TextView posterText;

    private int moviePosition;

    public AddEditMovieOnclickListener(Activity activity, EditText titleText, EditText yearText, TextView posterText, int moviePosition) {
        this.activity = activity;
        this.titleText = titleText;
        this.yearText = yearText;
        this.posterText = posterText;
        this.moviePosition = moviePosition;
    }

    @Override
    public void onClick(final View v) {



        if (titleText.getText().toString().isEmpty()) {
            dataManager.showAlert("Title can not be empty", v.getContext());
        } else if (yearText.getText().toString().isEmpty()) {
            dataManager.showAlert("Year can not be empty", v.getContext());
        } else if (posterText.getText().toString().isEmpty()) {
            dataManager.showAlert("Poster can not be empty", v.getContext());
        } else {

            if(moviePosition == -1){
                Movie movie = new Movie(System.currentTimeMillis()+"", titleText.getText().toString(), yearText.getText().toString(), posterText.getText().toString());
               dataManager.moviesList.add(movie);

            }else{
                Movie movie =  dataManager.moviesList.get(moviePosition);
                movie.setTitle(titleText.getText().toString());
                movie.setYear(yearText.getText().toString());
                movie.setPoster(posterText.getText().toString());


            }

 activity.finish();
            Toast.makeText(activity, "Movie has been saved", Toast.LENGTH_SHORT).show();
        }

    }
}
