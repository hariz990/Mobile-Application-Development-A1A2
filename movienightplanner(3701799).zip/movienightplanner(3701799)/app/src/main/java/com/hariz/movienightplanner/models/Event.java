/**
 Event: An event is a social movie viewing activity that occurs at a specific
 date, time and location and has a number of attendees. It must (at a
 minimum) maintain the following information:
 - Id: A randomly generated combination of numbers and letters, which
 uniquely identifies an event (not visible to the user).
 - Title: The title of the event (e.g. “Scary Saturday!”)
 - Start Date: The start date and time of an Event (e.g. April 6th, 2019,
 7.30PM)
 - End Date: The end date and time of an Event (must be later than start
 date)
 - Venue: The location of the event (e.g. “MegaDupaMultiPlex, 13
 Node.js”)
 - Location: A String representation of geographical latitude and longitude
 of the venue (e.g. -37.805631, 144.963053), you can get this from
 Google Maps web page directly (i.e. outside of your app by just copying
 and pasting the data).
 - Attendees: A list of individuals who are invited to this event (as picked
 from the user’s contacts list .. see supplied contacts_data/).
  */


package com.hariz.movienightplanner.models;


import java.util.ArrayList;
import java.util.List;

public class Event {

    private String id;
    private String title;
    private String startDate;
    private String endDate;
    private String venue;
    private String location;
    private Movie movie;
    private List<String> attendees;

    public Event(String id, String title, String startDate, String endDate, String venue, String location) {
        this.id = id;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.venue = venue;
        this.location = location;
        this.attendees = new ArrayList<>();
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public List<String> getAttendees() {
        return attendees;
    }

    public void setAttendees(List<String> attendees) {
        this.attendees = attendees;
    }

}
