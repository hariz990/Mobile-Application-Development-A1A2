package com.hariz.movienightplanner.views.event;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.listeners.EventDetailContactListLongClickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.views.contact.ContactsActivity;
import com.hariz.movienightplanner.views.movie.MovieSelectorActivity;

import java.io.IOException;
import java.io.InputStream;

public class EventDetailActivity extends AppCompatActivity {

    private int eventPosition;
    private ArrayAdapter<String> adapter;
    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();

    private TextView eventTittleText;
    private TextView venueText;
    private TextView locationText;
    private TextView startDateText;
    private TextView endDateText;
    private ImageView movieImage;
    private TextView movieNameText;
    private TextView movieInfoText;
    private ListView listView;
    private View viewMovieDetail;
    private View viewNoMovie;
    private View viewNoAttendees;
    private View viewAttendees;

    public EventDetailActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.event_detail);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        listView = (ListView) findViewById(R.id.listAttendees);
        viewMovieDetail = findViewById(R.id.lytMovie);
        viewNoMovie = findViewById(R.id.lytNoMovie);
        viewNoAttendees = findViewById(R.id.lytNoAttendees);
        viewAttendees = findViewById(R.id.lytAttendees);
        venueText = (TextView) findViewById(R.id.txtVenue);
        eventTittleText = (TextView) findViewById(R.id.txtTitle);
        movieNameText = (TextView) findViewById(R.id.txtMovieName);
        startDateText = (TextView) findViewById(R.id.txtStartDate);
        endDateText = (TextView) findViewById(R.id.txtEndDate);
        movieImage = (ImageView) findViewById(R.id.movieImageView1ID);
        movieInfoText = (TextView) findViewById(R.id.txtMovieYear);
        locationText = (TextView) findViewById(R.id.txtLocation);

        populateData();
    }

    private void populateData() {
        Event event = dataManager.eventLists.get(eventPosition);
        eventPosition = getIntent().getIntExtra("position", -1);
        if(eventPosition == -1){
           // pending intent case
            InMemoryDataManager.getSharedInstance().loadData(this);
            eventPosition = InMemoryDataManager.getSharedInstance().findEventIndexById(getIntent().getStringExtra("eventId"));

        }

        eventTittleText.setText(event.getTitle());
        venueText.setText("Venue: " + event.getVenue());
        startDateText.setText("Start Date: " + event.getStartDate());
        endDateText.setText("End Date: " + event.getEndDate());
        if (event.getMovie() != null) {
            viewMovieDetail.setVisibility(View.VISIBLE);
            viewNoMovie.setVisibility(View.GONE);
            String imageName = event.getMovie().getPoster().replace(" ", "").toLowerCase().trim();
//            int resID = getResources().getIdentifier(imageName, "drawable", getPackageName());
//            movieImage.setImageResource(resID);


            try {
                InputStream inputStream = getAssets().open("posters/" + imageName);
                Drawable d = Drawable.createFromStream(inputStream, null);
                movieImage.setImageDrawable(d);
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();

            }

            movieNameText.setText(event.getMovie().getTitle());

            movieInfoText.setText(event.getMovie().getYear());

        } else {
            viewMovieDetail.setVisibility(View.GONE);
            viewNoMovie.setVisibility(View.VISIBLE);
        }

        if (event.getAttendees().size() > 0) {
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, event.getAttendees());
            listView.setAdapter(adapter);
            viewNoAttendees.setVisibility(View.GONE);
            viewAttendees.setVisibility(View.VISIBLE);
        } else {
            viewNoAttendees.setVisibility(View.VISIBLE);
            viewAttendees.setVisibility(View.GONE);
        }
        locationText.setText("Location: " + event.getLocation());
        listView.setOnItemLongClickListener(new EventDetailContactListLongClickListener(eventPosition, adapter));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_eventdetail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;

            case R.id.menuDelete:

                dataManager.eventLists.remove(eventPosition);
                onBackPressed();
                Toast.makeText(this, "Event Deleted", Toast.LENGTH_SHORT).show();
                break;

        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateData();
    }

    public void addMovie(View view) {
        Intent intent = new Intent(EventDetailActivity.this, MovieSelectorActivity.class);
        intent.putExtra("position", eventPosition);
        startActivity(intent);
    }

    public void addAttendees(View view) {
        Intent intent = new Intent(EventDetailActivity.this, ContactsActivity.class);
        intent.putExtra("position", eventPosition);
        startActivity(intent);
    }


    public void editEvent(View view) {
        Intent intent = new Intent(EventDetailActivity.this, AddEditEventActivity.class);
        intent.putExtra("position", eventPosition);
        startActivity(intent);
    }
}
