package com.hariz.movienightplanner.views.event;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.listeners.AddNewEventOnClickListener;
import com.hariz.movienightplanner.listeners.EditEventOnclickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.models.helper.Constants;

import java.util.Calendar;

public class AddEditEventActivity extends AppCompatActivity {

    private static final int PLACE_PICKER_REQUEST = 103;
    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private EditText titleText;
    private EditText startDateText;
    private EditText endDateText;
    private EditText venueText;
    private EditText locationText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int eventPosition = getIntent().getIntExtra("position", -1);
        if(eventPosition > -1){
            toolbar.setTitle(R.string.edit_event);
        } else {
            toolbar.setTitle(R.string.add_event);
        }

        View saveButton;

        saveButton =  findViewById(R.id.fab);
        titleText = (EditText) findViewById(R.id.edtTitle);
        startDateText = (EditText) findViewById(R.id.edtStartDate);
        endDateText = (EditText) findViewById(R.id.edtEndDate);
        venueText = (EditText) findViewById(R.id.edtVenue);
        locationText = (EditText) findViewById(R.id.edtLocation);

        if (eventPosition != -1) {
            Event event = dataManager.eventLists.get(eventPosition);
            titleText.setText(event.getTitle());
            startDateText.setText(event.getStartDate());
            endDateText.setText(event.getEndDate());
            venueText.setText(event.getVenue());
            locationText.setText(event.getLocation());
            saveButton.setOnClickListener(new EditEventOnclickListener(this, titleText,startDateText,endDateText,venueText,locationText, eventPosition));

        }else{
            saveButton.setOnClickListener(new AddNewEventOnClickListener(this, titleText,startDateText,endDateText,venueText,locationText));

        }
        setupDatePicker(startDateText);
        setupDatePicker(endDateText);
        setupLocationPicker();

    }

    private void setupLocationPicker() {
        locationText.setFocusable(false);
        locationText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickLocation();
            }
        });
    }

    private void setupDatePicker(final EditText ediTtext) {
        ediTtext.setClickable(true);
        ediTtext.setFocusable(false);
        ediTtext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimePicker(ediTtext);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }

    public void showDateTimePicker(final EditText editText) {
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        );

        final Calendar currentDate = Calendar.getInstance();
        final Calendar date = Calendar.getInstance();
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                date.set(year, monthOfYear, dayOfMonth);
                new TimePickerDialog(AddEditEventActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        date.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        date.set(Calendar.MINUTE, minute);
                        editText.setText(android.text.format.DateFormat.format(Constants.DATETIME_FORMAT_FULL, date));

                    }
                }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), false).show();
            }
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DATE)).show();
    }

    private void pickLocation(){
        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

        try {
            startActivityForResult(builder.build(this), PLACE_PICKER_REQUEST);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                locationText.setText(place.getLatLng().latitude+","+place.getLatLng().longitude);
                Toast.makeText(this, "Location updated", Toast.LENGTH_LONG).show();
            }
        }
    }


}
