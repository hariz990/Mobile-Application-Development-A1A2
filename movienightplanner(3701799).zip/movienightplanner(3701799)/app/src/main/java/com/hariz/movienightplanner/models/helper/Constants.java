package com.hariz.movienightplanner.models.helper;

public class Constants {
    public static final String DATETIME_FORMAT = "d/MM/yyyy h:mm:ss";
    public static final String DATETIME_FORMAT_FULL = "d/MM/yyyy h:mm:ss a";

    public static final String MONTH_FORMAT = "MMMM yyyy";
    public static final String CALENDARDATE_FORMAT = "yyyyMMdd";
}
