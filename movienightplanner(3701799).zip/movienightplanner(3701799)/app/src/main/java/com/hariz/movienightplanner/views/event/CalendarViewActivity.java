package com.hariz.movienightplanner.views.event;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.adapter.CalendarGridAdapter;
import com.hariz.movienightplanner.listeners.CalendarOnItemClickListener;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Day;
import com.hariz.movienightplanner.models.helper.CustomCalendarHelper;

import java.util.ArrayList;
import java.util.List;

public class CalendarViewActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();

    private ImageView preMonth;
    private ImageView nextMonth;
    private TextView currentDate;
    private GridView calendarGrids;
    private List<Day> days;
    private CalendarGridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_view);

        preMonth = findViewById(R.id.previous_month);
        nextMonth = findViewById(R.id.next_month);
        currentDate = findViewById(R.id.display_current_date);
        calendarGrids = findViewById(R.id.calendar_grid);

        currentDate.setText(CustomCalendarHelper.long2str(CustomCalendarHelper.getCurrentTime()));

        days = new ArrayList<Day>();
        adapter = new CalendarGridAdapter(this, days);
        CustomCalendarHelper.setCalendarList(CustomCalendarHelper.getFirOfMonth(CustomCalendarHelper.getCurrentTime()), days, calendarGrids, adapter, this);

        //show last month
        preMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomCalendarHelper.setCalendarList(CustomCalendarHelper.getFirOfMonth(CustomCalendarHelper.getLastMonth(CustomCalendarHelper.getCurrentTime(), -1)), days, calendarGrids, adapter, CalendarViewActivity.this);
                currentDate.setText(CustomCalendarHelper.long2str(CustomCalendarHelper.getCurrentTime()));
            }
        });

        //show next month
        nextMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomCalendarHelper.setCalendarList(CustomCalendarHelper.getFirOfMonth(CustomCalendarHelper.getNextMonth(CustomCalendarHelper.getCurrentTime(), 1)), days, calendarGrids, adapter, CalendarViewActivity.this);
                currentDate.setText(CustomCalendarHelper.long2str(CustomCalendarHelper.getCurrentTime()));
            }
        });

        //entry to the event, event handling code is in a separate class called CalendarOnItemClickListener
        calendarGrids.setOnItemClickListener(new CalendarOnItemClickListener(days));

        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.calendarViewToolbar);
        toolbar.setTitle(R.string.event_calendar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;



        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        CustomCalendarHelper.setCalendarList(CustomCalendarHelper.getFirOfMonth(CustomCalendarHelper.getCurrentTime()), days, calendarGrids, adapter, this);
        adapter.notifyDataSetChanged();
    }

    public void addEvent(View view) {
        startActivity(new Intent(CalendarViewActivity.this, AddEditEventActivity.class));

    }
}
