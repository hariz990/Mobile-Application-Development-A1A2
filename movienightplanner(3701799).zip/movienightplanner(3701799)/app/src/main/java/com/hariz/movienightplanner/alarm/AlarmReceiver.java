package com.hariz.movienightplanner.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.hariz.movienightplanner.service.DistanceMatrixIntentService;


public class AlarmReceiver extends BroadcastReceiver
{

    public static final int REQUEST_CODE = 100;

    @Override
    public void onReceive(Context context, Intent intent)
    {
        Toast.makeText(context, "AlarmReceiver: Starting distance check service", Toast.LENGTH_SHORT).show();
        context.startService(
                new Intent(context, DistanceMatrixIntentService.class));
    }
}
