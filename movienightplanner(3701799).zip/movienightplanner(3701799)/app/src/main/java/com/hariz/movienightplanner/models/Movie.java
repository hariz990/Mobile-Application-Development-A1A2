/**
 Movie: Each event has associated details of the movie to be viewed/screened
 as follows:
 - Id: A randomly generated combination of numbers and letters, which
 uniquely identifies a movie (not visible to the user)..
 - Title: The title of the movie (e.g. “Blade Runner”)
 - Year: the year the movie was released (e.g. 1982)
 - Poster: an image of the poster used to promote the movie.
 NOTE: use of copyrighted material for education purposes in your
 assignment is covered under fair use i.e.
 https://www.alrc.gov.au/publications/4-case-fair-use-australia/what-fairuse
 but should not be redistributed outside the educational setting.
 */
package com.hariz.movienightplanner.models;

public class Movie  {

    private String id;
    private String title;
    private String year;
    private String poster;

    public Movie(String id, String title, String year, String poster) {
        this.id = id;
        this.title = title;
        this.year = year;
        this.poster = poster;
    }

    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }


    public String getYear() {
        return year;
    }


    public void setYear(String year) {
        this.year = year;
    }


    public String getPoster() {
        return poster;
    }


    public void setPoster(String poster) {
        this.poster = poster;
    }
}
