package com.hariz.movienightplanner.models;

import java.util.Calendar;

public class Day {

    private Boolean isCurrentMonth = false;
    private Boolean hasEvent = false;
    private int day;
    private Calendar calendar;

    
    public boolean getIsCurrentMonth() {
        return isCurrentMonth;
    }

    
    public void setIsCurrentMonth(Boolean bool) {
        isCurrentMonth = bool;
    }

    
    public int getDay() {
        return day;
    }

    
    public void setDay(int day) {
        this.day = day;
    }

    
    public Calendar getCalendar() {
        return calendar;
    }

    
    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    
    public boolean getHasEvent() {
        return hasEvent;
    }

    
    public void setHasEvent(Boolean bool) {
        this.hasEvent = bool;
    }
}
