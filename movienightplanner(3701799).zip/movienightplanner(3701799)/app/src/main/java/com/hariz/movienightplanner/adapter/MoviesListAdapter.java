package com.hariz.movienightplanner.adapter;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.Movie;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MoviesListAdapter extends ArrayAdapter {


    private Activity context;

    private List<Movie> moviesList;

    public MoviesListAdapter(Activity context, List<Movie> moviesList) {

        super(context, R.layout.movie_listview_row, moviesList);

        this.context = context;

        this.moviesList = moviesList;

    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.movie_listview_row, null, true);

        ImageView imageView = (ImageView) rowView.findViewById(R.id.imgPoster);
        TextView name = (TextView) rowView.findViewById(R.id.txtMovieName);
        TextView year = (TextView) rowView.findViewById(R.id.txtMovieYear);

        //this code sets the values of the objects to values from the list
        String imageName = moviesList.get(position).getPoster().replace(" ", "").toLowerCase().trim();
//        int resID = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
//        imageView.setImageResource(resID);
        InputStream inputStream = null;
        try {
            inputStream = context.getAssets().open("posters/" +imageName);
            Drawable d = Drawable.createFromStream(inputStream, null);
            imageView.setImageDrawable(d);
            inputStream.close();
        } catch (IOException e) {
e.printStackTrace();

        }

        name.setText(moviesList.get(position).getTitle());
        year.setText(moviesList.get(position).getYear());
        return rowView;

    }

}
