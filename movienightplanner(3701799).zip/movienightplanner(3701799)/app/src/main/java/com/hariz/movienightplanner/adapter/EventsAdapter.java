package com.hariz.movienightplanner.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.views.MainActivity;

import java.util.List;

public class EventsAdapter extends ArrayAdapter {

    private Activity context;

    private List<Event> eventsList;

    public EventsAdapter(Activity context, List<Event> eventsList) {

        super(context, R.layout.item_event_list, eventsList);

        this.context = context;

        this.eventsList = eventsList;

    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.item_event_list, null, true);

        TextView txtTitle = layout.findViewById(R.id.txtTitle);
        TextView txtVenue = layout.findViewById(R.id.txtVenue);
        TextView txtDate =  layout.findViewById(R.id.txtDate);
        TextView txtAttendee = layout.findViewById(R.id.txtAttendees);
        TextView txtMovie = layout.findViewById(R.id.txtMovie);

        Event event = eventsList.get(position);
        txtTitle.setText(event.getTitle());
        txtVenue.setText("Venue: "+event.getVenue());
        txtAttendee.setText("Attendees: "+event.getAttendees().size());
        txtDate.setText(event.getStartDate() + " - " + event.getEndDate());
        if(event.getMovie() != null) {
            txtMovie.setText("Movie: "+event.getMovie().getTitle());
        }else{
            txtMovie.setText("No Movie");
        }
        return layout;

    }
}
