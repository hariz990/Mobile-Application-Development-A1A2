package com.hariz.movienightplanner.location;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.util.Log;



import static android.content.Context.LOCATION_SERVICE;

public class LocationTracker
{
    private static final String LOG_TAG = LocationTracker.class.getSimpleName();

    public static void getLocation(Context context, LocationListener locationListener)
    {
        LocationManager locationManager = (LocationManager)
                context.getSystemService(LOCATION_SERVICE);
        Location location = null;

        boolean networkAvailable = locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER);
        boolean gpsAvailable = locationManager.isProviderEnabled(
                LocationManager.GPS_PROVIDER);

        // Get location from GPS if available
        if (gpsAvailable)
        {
            try
            {
                locationManager.requestSingleUpdate(
                        LocationManager.GPS_PROVIDER,
                        locationListener, null);

            }
            catch(SecurityException e)
            {
                Log.i(LOG_TAG, "Cannot get location from GPS, android"
                        + ".permission.ACCESS_FINE_LOCATION not granted.");
            }
        }
        // Otherwise, get location from network if available
        else if (networkAvailable)
        {
            try
            {
                locationManager.requestSingleUpdate(
                        LocationManager.NETWORK_PROVIDER,
                        locationListener, null);

            }
            catch(SecurityException e)
            {
                Log.i(LOG_TAG, "Cannot get location from network, android"
                        + ".permission.ACCESS_COARSE_LOCATION not granted.");
            }
        }

    }


}
