package com.hariz.movienightplanner.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.Day;
import com.hariz.movienightplanner.views.event.CalendarViewActivity;

import java.util.List;

public class CalendarGridAdapter extends ArrayAdapter {

    private CalendarViewActivity context;
    private List<Day> beans;

    public CalendarGridAdapter(CalendarViewActivity context, List<Day> beans) {

        super(context, R.layout.item_event_list, beans);

        this.context = context;

        this.beans = beans;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        GridColumnViewHolder holder;
        LayoutInflater inflater = context.getLayoutInflater();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_layout, null);
            holder = new GridColumnViewHolder();
            holder.day_text = (TextView) convertView.findViewById(R.id.day_text);
            convertView.setTag(holder);
        } else {
            holder = (GridColumnViewHolder) convertView.getTag();
        }
        holder.day_text.setText("" + beans.get(position).getDay());

        if (beans.get(position).getIsCurrentMonth()) {
            holder.day_text.setTextColor(Color.BLACK);
        } else {
            holder.day_text.setTextColor(Color.WHITE);
        }

        if (beans.get(position).getHasEvent()) {
            holder.day_text.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
            holder.day_text.setTextColor(Color.WHITE);
        }



        return convertView;
    }

    private class GridColumnViewHolder {
        public TextView day_text;
    }
}
