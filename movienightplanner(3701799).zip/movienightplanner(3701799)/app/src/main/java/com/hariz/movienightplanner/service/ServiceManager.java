package com.hariz.movienightplanner.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.widget.Toast;

import com.hariz.movienightplanner.alarm.AlarmReceiver;


public class ServiceManager
{
    private static ServiceManager singletonInstance = null;


    private PendingIntent alarmIntent;
    private AlarmManager alarmManager;
    private Context context;

    public static ServiceManager getSingletonInstance(Context context)
    {
        if (singletonInstance == null)
        {
            singletonInstance = new ServiceManager(context);
        }
        return singletonInstance;
    }

    private ServiceManager(Context context)
    {

        this.context = context;
    }


    public void startDistanceMatrixBackgroundService(boolean forceRestart)
    {
        if (isAlarmRunning(context))
        {
            if(!forceRestart){
                Toast.makeText(context, "Distance Matrix Service already running.", Toast.LENGTH_SHORT).show();
                return;
            }
            stopBackgroundDistanceMatrixService();
        }
        Intent intent = new Intent(context.getApplicationContext(),
                AlarmReceiver.class);

        alarmIntent = PendingIntent.getBroadcast(context,
                AlarmReceiver.REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        alarmManager = (AlarmManager) context.getSystemService(
                Context.ALARM_SERVICE);

        SharedPreferences prefs = PreferenceManager
                .getDefaultSharedPreferences(context.getApplicationContext());
        long interval = prefs.getLong("distance_check_freq_interval",
                DistanceMatrixIntentService.DEFAULT_INTERVAL_MS);

        alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime(), interval, alarmIntent);
        Toast.makeText(context, "Distance Matrix Service started.", Toast.LENGTH_SHORT).show();

    }


    private boolean isAlarmRunning(Context context) {
        Intent intent = new Intent(context.getApplicationContext(),
                AlarmReceiver.class);

        return PendingIntent.getBroadcast(context.getApplicationContext(),
                AlarmReceiver.REQUEST_CODE, intent,
                PendingIntent.FLAG_NO_CREATE)
                != null;
    }
    private void stopBackgroundDistanceMatrixService()
    {
        if (alarmManager != null && alarmIntent != null)
        {
            alarmManager.cancel(alarmIntent);
            alarmIntent.cancel();
        }
    }

}
