/**
 - View Events: Users should be able to display a list of events where each
 element in the list will be a synoptic view (summary) of the Event e.g.
 event title, date, venue, movie title and number of attendees. The list
 should be sorted according to date (user can toggle
 ascending/descending order).
 */

package com.hariz.movienightplanner.views.event;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.adapter.EventsAdapter;
import com.hariz.movienightplanner.listeners.EventListViewOnItemClickListener;
import com.hariz.movienightplanner.models.Event;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.views.MainActivity;

public class EventsListActivity extends AppCompatActivity {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private ListView listView;
    private EventsAdapter eventAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);


        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.events));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        eventAdapter = new EventsAdapter(this, dataManager.eventLists);
        listView = (ListView) findViewById(R.id.listView);
        eventAdapter.notifyDataSetChanged();
        listView.setAdapter(eventAdapter);

        listView.setOnItemClickListener(new EventListViewOnItemClickListener());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_event_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;

            case R.id.menuAscending:

                dataManager.ascendEvents();

                eventAdapter = new EventsAdapter(this, dataManager.eventLists);
                eventAdapter.notifyDataSetChanged();
                listView.setAdapter(eventAdapter);

                break;

            case R.id.menuDescending:

                dataManager.descendEvents();

                eventAdapter = new EventsAdapter(this, dataManager.eventLists);
                eventAdapter.notifyDataSetChanged();
                listView.setAdapter(eventAdapter);

                break;

        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        eventAdapter.notifyDataSetChanged();
    }

    public void createNewEvent(View view) {
        startActivity(new Intent(EventsListActivity.this, AddEditEventActivity.class));

    }


}
