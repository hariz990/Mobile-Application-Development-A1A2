/**
 - View Events: Users should be able to display a list of events where each
 element in the list will be a synoptic view (summary) of the Event e.g.
 event title, date, venue, movie title and number of attendees. The list
 should be sorted according to date (user can toggle
 ascending/descending order).
 */

package com.hariz.movienightplanner.views;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.location.LocationListener;
import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.service.ServiceManager;
import com.hariz.movienightplanner.views.event.AddEditEventActivity;
import com.hariz.movienightplanner.views.event.CalendarViewActivity;
import com.hariz.movienightplanner.views.event.EventsListActivity;
import com.hariz.movienightplanner.views.movie.MovieListActivity;
import com.hariz.movienightplanner.views.settings.SettingsActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS_LOCATION = 105;
    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.dashboard));
        setSupportActionBar(toolbar);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            checkLocationPermission();

            return;
        }else{
            checkGpsStatus();
            ServiceManager.getSingletonInstance(this).startDistanceMatrixBackgroundService(false);

        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        // Load data from db
        if (!dataManager.getDataRead()) {
            dataManager.loadData(this);
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        // Save data to db
        dataManager.saveData(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dataManager.saveData(this);

    }

    public void gotoEventsList(View view) {
        startActivity(new Intent(this, EventsListActivity.class));
    }

    public void gotoMovies(View view) {
        startActivity(new Intent(this, MovieListActivity.class));

    }

    public void gotoEventsCalendar(View view) {
        startActivity(new Intent(this, CalendarViewActivity.class));

    }

    public void gotoSettings(View view) {
        startActivity(new Intent(this, SettingsActivity.class));

    }
// Location permission

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        REQUEST_PERMISSIONS_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_PERMISSIONS_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSIONS_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, "Location permission granted", Toast.LENGTH_SHORT).show();
                    ServiceManager.getSingletonInstance(this).startDistanceMatrixBackgroundService(false);


                } else {
                    Toast.makeText(this, "Location permission denied. App would not work properly.", Toast.LENGTH_SHORT).show();


                }
                return;
            }

        }
    }

    public void checkGpsStatus() {
        final LocationManager manager = (LocationManager) getSystemService(
                Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(
                "Your GPS seems to be disabled, please enable it?")
                .setCancelable(false).setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog,
                                        final int id) {
                        startActivity(new Intent(
                                android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog,
                                        final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }


}
