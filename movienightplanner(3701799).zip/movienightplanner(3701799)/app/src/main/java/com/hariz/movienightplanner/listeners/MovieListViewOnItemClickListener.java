package com.hariz.movienightplanner.listeners;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.hariz.movienightplanner.R;
import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.views.movie.MovieSelectorActivity;

public class MovieListViewOnItemClickListener implements AdapterView.OnItemClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private MovieSelectorActivity moviesActivity;
    private Intent intent;

    public MovieListViewOnItemClickListener(MovieSelectorActivity moviesActivity, Intent intent) {
        this.moviesActivity = moviesActivity;
        this.intent = intent;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
        int eventPosition = intent.getIntExtra("position", 1);
        dataManager.eventLists.get(eventPosition).setMovie(dataManager.moviesList.get(position));
        Toast.makeText(moviesActivity, moviesActivity.getString(R.string.movie_added_to_event), Toast.LENGTH_SHORT).show();
        moviesActivity.finish();
    }
}
