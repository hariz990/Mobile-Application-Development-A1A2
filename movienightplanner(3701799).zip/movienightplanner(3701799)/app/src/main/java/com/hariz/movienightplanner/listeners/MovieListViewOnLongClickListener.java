package com.hariz.movienightplanner.listeners;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.hariz.movienightplanner.models.InMemoryDataManager;
import com.hariz.movienightplanner.models.Movie;
import com.hariz.movienightplanner.views.movie.AddEditMovieActivity;

public class MovieListViewOnLongClickListener implements AdapterView.OnItemLongClickListener {

    public InMemoryDataManager dataManager = InMemoryDataManager.getSharedInstance();
    private Activity activity;
    private ArrayAdapter adapter;

    public MovieListViewOnLongClickListener(Activity activity, ArrayAdapter adapter) {
        this.activity = activity;
        this.adapter = adapter;
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

            Movie movie = dataManager.moviesList.get(position);
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            CharSequence [] items = new CharSequence[2];
            items[0] = "Edit";
        items[1] = "Delete";
        builder.setItems(items,new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
switch (which){
    case 0:
        Intent intent = new Intent(MovieListViewOnLongClickListener.this.activity, AddEditMovieActivity.class);
        intent.putExtra("position", position);
        activity.startActivity(intent);
        dialog.cancel();
        break;

    case 1:
        dataManager.moviesList.remove(position);
        adapter.notifyDataSetChanged();
        dialog.cancel();
        break;
}
            }
        });

            builder.setCancelable(true);

            builder.setPositiveButton(
                    "Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                           dialog.dismiss();
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();

            return true;
        }


}